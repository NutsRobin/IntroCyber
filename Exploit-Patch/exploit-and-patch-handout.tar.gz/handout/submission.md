# Start Here

`Name`: Your name  
`NetID`: Your netid

For each problem below, you will,

1. Fill in the the flag
2. List the steps necessary to exploit the binary. *(May be a single line.)*
3. Provide a patch that fixes the exploit. *(Generated using `make diff`.)*
4. An explanation of what the vulnerability was and how the patch fixes it. *(Keep this explanation short and to the point.)*

---

## problem1

### Flag
`flag{CS366-VALUE_GOES_HERE}`

### Exploit Steps
1. List your steps here

### Patch
```diff
+ Contents of ./diff/problem1.diff goes here
```

### Explanation
In your own words, write a couple sentences about why this code is vulnerable and how you fixed this vulnerability. *(Keep to 200 words or less; preferrably much less.)*

---

## problem2

### Flag
FLAG_GOES_HERE

### Exploit Steps
1. List your steps here

### Patch
```diff
+ Contents of ./diff/problem2.diff goes here
```

### Explanation
In your own words, write a couple sentences about why this code is vulnerable and how you fixed this vulnerability. *(Keep to 200 words or less; preferrably much less.)*

---

## problem3

### Flag
FLAG_GOES_HERE

### Exploit Steps
1. List your steps here

### Patch
```diff
+ Contents of ./diff/problem3.diff goes here
```

### Explanation
In your own words, write a couple sentences about why this code is vulnerable and how you fixed this vulnerability. *(Keep to 200 words or less; preferrably much less.)*

---

## problem4

### Flag
FLAG_GOES_HERE

### Exploit Steps
1. List your steps here

### Patch
```diff
+ Contents of ./diff/problem4.diff goes here
```

### Explanation
In your own words, write a couple sentences about why this code is vulnerable and how you fixed this vulnerability. *(Keep to 200 words or less; preferrably much less.)*

---

## problem5

### Flag
FLAG_GOES_HERE

### Exploit Steps
1. List your steps here

### Patch
```diff
+ Contents of ./diff/problem5.diff goes here
```

### Explanation
In your own words, write a couple sentences about why this code is vulnerable and how you fixed this vulnerability. *(Keep to 200 words or less; preferrably much less.)*

---

## problem6

### Flag
FLAG_GOES_HERE

### Exploit Steps
1. List your steps here

### Patch
```diff
+ Contents of ./diff/problem6.diff goes here
```

### Explanation
In your own words, write a couple sentences about why this code is vulnerable and how you fixed this vulnerability. *(Keep to 200 words or less; preferrably much less.)*

---

## problem7

### Flag
FLAG_GOES_HERE

### Exploit Steps
1. List your steps here

### Patch
```diff
+ Contents of ./diff/problem7.diff goes here
```

### Explanation
In your own words, write a couple sentences about why this code is vulnerable and how you fixed this vulnerability. *(Keep to 200 words or less; preferrably much less.)*

---
